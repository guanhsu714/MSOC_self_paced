
project 	-prefixsum
reference	-pp4fpga
+code
|  	+---src							: This folder contains C++ design files and header file.
	|       prefixsum.cpp
	|       prefixsum_original.cpp
	|		
	|
	+---tb							: This folder contains a C++ design file that serves as the test bench. 
	|       prefixsum_tb.cpp
	|    
	+---python						: This folder contains python file for demo.
	|		prefixsum.py
|
+impl
|	prefixsum_csynth.rpt
|
+script
|	script.tcl
|