
project 	-histogram
reference	-pp4fpga
+code
|  	+---src							: This folder contains C++ design files and header file.
	|       histogram.cpp
	|       histogram.h
	|       histogram_original.cpp
	|		
	|
	+---tb							: This folder contains a C++ design file that serves as the test bench. 
	|       histogram_tb.cpp
	|    
	+---python						: This folder contains python file for demo.
	|		histogram.py
|
+impl
|	histogram_csynth.rpt
|
+script
|	script.tcl
|