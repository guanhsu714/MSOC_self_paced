
project		-differene squared accumulation
reference	-Xilinx HLx Example
+code
|  	+---src							: This folder contains C++ design files and header file.
	|       diff_sq_acc.cpp
	|       diff_sq_acc.h
	|		diff_sq_acc_original.cpp
	|       
	+---tb							: This folder contains a C++ design file that serves as the test bench. 
	|       diff_sq_acc_tb.cpp
	|    
	+---python						: This folder contains python file for demo.
	|		diff_sq_acc.py
|
+impl
|	diff_sq_acc_csynth.rpt
|
+script
|	script.tcl
|
   